package concurrency.basic;

public class HelloWorldRunnable implements Runnable {

	public void run() {
		try {
			Thread.sleep(2000);
		} catch(InterruptedException ex) {
			return;
		}
		System.out.println("Hello World");
	}
}
