package concurrency.basic;

public class HelloWorldThread extends Thread {

	public void run() {
		System.out.println("Hello World");
	}

	public static void main(String[] args) {
		new HelloWorldThread().start();
		System.out.println("Hello from main");
	}

}
