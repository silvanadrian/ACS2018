package junitsamples.ringcounter;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.Test;

public class RingCounterTest {

	private static final int N_TEST = 1000;
	Random r = new Random();
	
	private RingCounter fresh() {
		return new SimpleRingCounter();
	}
	
	@Test
	public void testGet() {
		RingCounter rc = fresh();
		assertEquals(1, rc.get());
	}
	
	@Test
	public void testConsistency() {
		for (int i = 0; i < N_TEST; i++) {
			RingCounter rc = fresh();
			rc.inc(r.nextInt(1000));
			assertTrue(rc.get() > 0 && rc.get() <= 16);
		}
	}


	@Test
	public void testInc() {
		RingCounter rc = fresh();
		rc.inc(16);
		assertEquals(1, rc.get());
		rc.inc(0);
		assertEquals(1, rc.get());
		rc.inc(5);
		assertEquals(6, rc.get());
		rc.inc(32);
		assertEquals(6, rc.get());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testIllegalArgument() {
		RingCounter rc = fresh();
		rc.inc(-10);
	}
	
	@Test
	public void testIllegalArgumentWithState() {
		RingCounter rc = fresh();
		rc.inc(10);
		int preExceptionValue = rc.get();
		try {
			rc.inc(-4);
			fail("Expected exception");
		} catch (IllegalArgumentException e) {
			// All good
		}
		int postExceptionValue = rc.get();
		assertEquals(preExceptionValue, postExceptionValue);
	}
}
