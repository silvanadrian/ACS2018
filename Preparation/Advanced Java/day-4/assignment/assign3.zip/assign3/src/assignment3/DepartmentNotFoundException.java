package assignment3;

/**
 * DepartmentNotFoundException is thrown when a department entry does not exist
 * 
 * @author bonii
 * 
 */
public class DepartmentNotFoundException extends Exception {

	public DepartmentNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public DepartmentNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DepartmentNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public DepartmentNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
