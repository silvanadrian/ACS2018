package communication.jetty;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;

public class SimpleConnectorServer {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {

		Server server = new Server();

		ServerConnector http = new ServerConnector(server);
		http.setHost("localhost");
		http.setPort(8088);
		http.setIdleTimeout(30000);
		server.addConnector(http);
		//server.setHandler(new SimpleHandler());
		//server.setHandler(new CounterHandler());
		//server.setHandler(new SimplePostHandler());
		server.setHandler(new ServerXStreamHandler());
		server.start();
		server.join();

	}

}
