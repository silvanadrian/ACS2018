package advjava.safety;

import java.util.ArrayList;
import java.util.List;

/**
 * An observable counter.
 */
public class ObservableCounter {
	private int c = 0;
	private final List<CounterObserver> observers = new ArrayList<CounterObserver>();

	public int getValue() {
		synchronized (this) {
			return c;
		}
	}

	public void incr() {
		synchronized (this) {
			c++;
		}
		notifyValueChanged();
	}

	public void addObserver(CounterObserver obs) {
		synchronized (observers) {
			observers.add(obs);
		}
	}

	public void removeObserver(CounterObserver obs) {
		synchronized (observers) {
			observers.remove(obs);
		}
	}

	private void notifyValueChanged() {
		synchronized (observers) {
			for (CounterObserver obs : observers)
				obs.counterChanged(this);
		}
	}
	
	/*private void notifyValueChanged() {
		List<CounterObserver> snapshot=null;
		synchronized (observers) {
			snapshot = new ArrayList<CounterObserver>(observers);
		}
		for (CounterObserver obs : snapshot)
			obs.counterChanged(this);
	}*/
}
