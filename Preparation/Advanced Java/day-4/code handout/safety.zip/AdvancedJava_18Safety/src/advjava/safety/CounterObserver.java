package advjava.safety;

/**
 * Interface implemented by classes that observe changes in an ObservableCounter.
 */

public interface CounterObserver {
    /**
     * Counter change callback.
     * @param counter Reference to the counter whose value has changed.
     */
	public void counterChanged(ObservableCounter counter);
}
