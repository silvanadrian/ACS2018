package advjava.safety;

public class ObservableCounterDemo {
	public static void main(String[] args) {
		final ObservableCounter counter = new ObservableCounter();
		counter.addObserver(new CounterObserver() {
			public void counterChanged(ObservableCounter counter) {
				System.out.println(counter.getValue());
				if (counter.getValue() >= 42)
					counter.removeObserver(this);
			}
		});
		for (int i = 0; i < 100; i++)
			counter.incr();
	}
}
