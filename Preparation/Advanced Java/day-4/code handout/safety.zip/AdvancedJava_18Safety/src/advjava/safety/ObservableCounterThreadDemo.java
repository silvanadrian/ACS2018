package advjava.safety;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ObservableCounterThreadDemo {
	public static void main(String[] args) {
		final ObservableCounter counter = new ObservableCounter();
		counter.addObserver(new CounterObserver() {
			public void counterChanged(final ObservableCounter counter) {
				System.out.println(counter.getValue());
				if (counter.getValue() >= 42) {
					ExecutorService svc = Executors.newSingleThreadExecutor();
					final CounterObserver this_ = this;
					try {
						svc.submit(new Runnable() {
							public void run() {
								counter.removeObserver(this_);
							}
						}).get();
					} catch (Exception ex) {
						throw new AssertionError(ex);
					} finally {
						svc.shutdown();
					}
				}
			}
		});
		for (int i = 0; i < 100; i++)
			counter.incr();
	}
}
