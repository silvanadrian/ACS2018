package concurrency.extended;

import java.util.ArrayList;
import java.util.List;

public class WaitNotifyBoundedBuffer<T> implements BoundedBuffer<T> {
	private List<T> objectList = new ArrayList<T>();
	private int maxBufferSize;

	public WaitNotifyBoundedBuffer(int buffer_size) {
		this.maxBufferSize = buffer_size;
	}

	public synchronized boolean isListEmpty() {
		if (objectList.size() == 0) {
			return true;
		}
		return false;
	}

	public synchronized boolean isListFull() {
		if (this.objectList.size() == maxBufferSize) {
			return true;
		}
		return false;
	}

	public synchronized T get() throws InterruptedException {
		T temp;
		while (isListEmpty()) {
			wait();
		}
		temp = objectList.get(0);
		objectList.remove(0);
		notifyAll();
		return temp;
	}

	public synchronized void put(T o) throws InterruptedException {
		while (isListFull()) {
			wait();
		}
		objectList.add(o);
		notifyAll();
	}

}
