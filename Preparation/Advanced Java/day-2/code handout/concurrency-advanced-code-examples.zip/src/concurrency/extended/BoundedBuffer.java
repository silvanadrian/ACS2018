package concurrency.extended;

/**
 * 
 * @author bonii
 * 
 */
public interface BoundedBuffer<T> {

	/**
	 * 
	 * @return
	 */
	public T get() throws InterruptedException;

	/**
	 * 
	 */
	public void put(T o) throws InterruptedException;
}
