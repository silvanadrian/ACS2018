package concurrency.extended;

import java.util.Random;

/**
 * 
 * @author bonii
 * 
 */
public class BoundedBufferProducerTask implements Runnable {
	BoundedBuffer<Integer> buffer;
	Random rng = new Random();

	public BoundedBufferProducerTask(BoundedBuffer<Integer> buffer) {
		this.buffer = buffer;
	}

	public void run() {
		Integer o = rng.nextInt();
		try {
			while (true) {
				System.out.println("Producer " + Thread.currentThread().getName()
						+ " attempts to push...");
				this.buffer.put(o);
			}
		} catch (InterruptedException ex) {
			ex.printStackTrace();
			return;
		}
	}

}
