package exercise1.jdbc;

import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertTrue;

import exercise1.jdbc.AccessException;
import exercise1.jdbc.DepartmentNotFoundException;
import exercise1.jdbc.DerbyEmployeeDB;
import exercise1.jdbc.Employee;
import exercise1.jdbc.EmployeeDB;
import exercise1.jdbc.NegativeSalaryIncrementException;
import exercise1.jdbc.SalaryIncrement;

public class DerbyEmployeeDBTest {
	private static EmployeeDB employeeDB = null;

	/**
	 * The method runs just once before the test cases run. If you want to
	 * change the behavior look at @Before and other annotations in JUnit
	 * @throws AccessException 
	 * 
	 * @throws Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws InstantiationException, AccessException {
	    //all the departments in a single db
	    List<Integer> departemtIds = new LinkedList<Integer>();
	    for (int i = 0; i < 10; i++) {
	        departemtIds.add(i);
	    }
	    
	    //create DB
		employeeDB = new DerbyEmployeeDB(departemtIds);
		assert (employeeDB != null);
		
		//cleanup DB, in case entries are left
        employeeDB.cleanupDB();
	}
	
	@Test
    public void insertAndListTest() throws DepartmentNotFoundException, AccessException {
        Employee empl = new Employee();
        empl.setDepartment(3);
        empl.setName("Bob");
        empl.setId(777);
        empl.setSalary(1337);
        
        employeeDB.addEmployee(empl);
        
        List<Integer> departmentIds = new ArrayList<Integer>();
        departmentIds.add(3);
        List<Employee> employees = employeeDB.listEmployeesInDept(departmentIds);
        assertTrue(employees.contains(empl));

    }

	@Test
	public void updateTest() throws DepartmentNotFoundException, AccessException, NegativeSalaryIncrementException {
	    Employee empl = new Employee();
        empl.setDepartment(1);
        empl.setName("Alice");
        empl.setId(5);
        empl.setSalary(3500);
        
        //add test employee
        employeeDB.addEmployee(empl);
        
        //increase his salary
        SalaryIncrement si = new SalaryIncrement();
        si.setDepartment(1);
        si.setIncrementBy((float) 500.5);
        List<SalaryIncrement> sil = new ArrayList<>();
        sil.add(si);
        employeeDB.incrementSalaryOfDepartment(sil);
        
        
        //check that salary has been increased
        List<Integer> departmentIds = new ArrayList<Integer>();
        departmentIds.add(1);
        List<Employee> employees = employeeDB.listEmployeesInDept(departmentIds);
        assertTrue(employees.contains(empl));
        
	}
	
	/**
	 * This method is run just once after the test cases finish to cleanup. If
	 * you want to change the behavior look at @After and other annotations in
	 * JUnit
	 * @throws AccessException 
	 */
	@AfterClass
	public static void tearDownAfterClass() throws AccessException {
        //cleanup DB
        employeeDB.cleanupDB();
	}
}
