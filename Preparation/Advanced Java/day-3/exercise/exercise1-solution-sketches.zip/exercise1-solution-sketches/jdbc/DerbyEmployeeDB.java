package exercise1.jdbc;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * An implementation of EmployeeDB interface which uses the Derby database
 * engine for the back-end database
 * 
 * @author bonii
 * 
 */
public class DerbyEmployeeDB implements EmployeeDB {
	private Connection conn = null;
	private final String databaseName = "employeeDB";
	private final String derbyDriver = "org.apache.derby.jdbc.EmbeddedDriver";
	private final String databaseURL = "jdbc:derby:" + databaseName
			+ ";create=true";
	
	private List<Integer> departmentIds; //list of departments this db is responsible for
	
	/**
	 * If the database does not exist, it creates a database else it creates a
	 * connection to the existing database. This does not mean it creates the
	 * tables as well.
	 * 
	 * @throws InstantiationException
	 */
	public DerbyEmployeeDB(List<Integer> departmentIds) throws InstantiationException {

		try {
			// Load the Derby database engine
			Class.forName(derbyDriver);
		} catch (ClassNotFoundException ex) {
			throw new InstantiationException(
					"Error loading Derby Database engine");
		}
		try {
			// Get a connection to the database and also creates the
			// database if it does not exist
			conn = DriverManager.getConnection(databaseURL);

			// This should not happen, the API should throw exception,
			// guarding just in case
			if (conn == null) {
				throw new InstantiationException(
						"Got a null connection!!Weird case!");
			}
		} catch (SQLException ex) {
			throw new InstantiationException(ex.getMessage());
		}
		
		try {
		    //set the commit mode for the db
            conn.setAutoCommit(false);
            
            //create the tables
            DerbyEmployeeDB.createEmployeeTableIfNonExistant(conn);
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		
		this.departmentIds = departmentIds;
	}
	
	/**
	 * checks if the given table name exists in the DB specified by the conn
	 * @param tablename
	 * @param conn
	 * @throws SQLException 
	 */
	public static boolean doesTableExist(String tablename, Connection conn) throws SQLException {
        DatabaseMetaData dbm = conn.getMetaData();
        ResultSet tables = dbm.getTables(null, null, "EMPLOYEE", null);
        return tables.next();
	}
	
	/**
	 * checks if a table "Employee" exists. Creates it if it doesn't
	 * @param conn
	 * @throws SQLException
	 */
	public static void createEmployeeTableIfNonExistant(Connection conn) throws SQLException {
        // check if "employee" table is there
    	if (!doesTableExist("EMPLOYEE", conn)) {
    	   // Table does not exist
    	   //create table  	    
            String createTableString = "CREATE TABLE EMPLOYEE ( ID INTEGER NOT NULL, NAME VARCHAR(32) NOT NULL, DEPARTMENT INTEGER NOT NULL, SALARY REAL NOT NULL, PRIMARY KEY(ID))";
            Statement stmt = null;
            try {
                stmt = conn.createStatement();
                if(stmt == null) {
                    System.out.println("Error creating statement");
                    return;
                }
                stmt.executeUpdate(createTableString);
                //conn.rollback();
                conn.commit();
            } catch(Throwable t) {
                t.printStackTrace();
            } finally {
                stmt.close();
            }
    	}
	 
    }

	@Override
	public void addEmployee(Employee emp) throws DepartmentNotFoundException, AccessException {
		if (! this.departmentIds.contains(emp.getDepartment())) {
		    throw new DepartmentNotFoundException();
		}

        try {
		
		//add to DB
		Statement stmt = conn.createStatement();
        stmt.executeUpdate("INSERT INTO EMPLOYEE (ID, NAME, DEPARTMENT, SALARY) VALUES (" 
		+ emp.getId() + ", '"
        + emp.getName() + "', "
        + emp.getDepartment() + ", "
        + emp.getSalary() + ")");
        conn.commit();
        stmt.close();
        
        } catch (SQLException e) {
            e.printStackTrace();
            throw new AccessException();
        }
	}

	@Override
	public List<Employee> listEmployeesInDept(List<Integer> departmentIds)
			throws DepartmentNotFoundException, AccessException {
		try {
		    //select query
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM EMPLOYEE");
            
            //map results
            List<Employee> employees = new LinkedList<>();
            while(rs.next()) {
                Employee emp = new Employee();
                emp.setId(rs.getInt("ID"));
                emp.setName(rs.getString("NAME"));
                emp.setDepartment(rs.getInt("DEPARTMENT"));
                emp.setSalary(rs.getFloat("SALARY"));
                employees.add(emp);
            }
            stmt.close();
            return employees;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new AccessException();
        }
	}

	@Override
	public void incrementSalaryOfDepartment(List<SalaryIncrement> salaryIncrements)
			throws DepartmentNotFoundException, NegativeSalaryIncrementException, AccessException {
		for(SalaryIncrement si : salaryIncrements) {
		    
		    if (si.getIncrementBy() < 0) {
		        throw new NegativeSalaryIncrementException();
		    }
		    
		    if (!this.departmentIds.contains(si.getDepartment())) {
		        throw new DepartmentNotFoundException();
		    }
		    
		    //get all employees in department
		    List<Integer> departmentList = new ArrayList<>();
		    departmentList.add(si.getDepartment());
		    List<Employee> employees = this.listEmployeesInDept(departmentList);
		    for (Employee emp : employees) {
		        //increase the salary
		        emp.setSalary(emp.getSalary() + si.getIncrementBy());
		        //persist updated employee
		        try {
                    DerbyEmployeeDB.updateEmployee(emp, conn);
                } catch (SQLException e) {
                    e.printStackTrace();
                    throw new AccessException();
                }
		    }
		}
	}
	
	/**
	 * updates an employee
	 * no validation is performed by this method
	 * @param emp
	 * @param conn
	 * @throws SQLException 
	 */
	public static void updateEmployee(Employee emp, Connection conn) throws SQLException {
	    PreparedStatement preparedStmt = conn.prepareStatement("update employee set salary = ? where id = ?");
	    preparedStmt.setFloat(1, emp.getSalary());
	    preparedStmt.setInt(2, emp.getId());
	    preparedStmt.executeUpdate();
	    conn.commit();
	}

	@Override
	public void cleanupDB() throws AccessException {
	    try {
	        
	        //get users
	        List<Employee> employees = null;
	        try {
                employees = this.listEmployeesInDept(this.departmentIds);
            } catch (DepartmentNotFoundException e) {
                //will not happen
            }
	        
	        //delete all users
	        PreparedStatement preparedStmt = conn.prepareStatement("delete from employee where id = ?");
	        for (Employee e : employees) {
	            //fill prepared statement
	            preparedStmt.setInt(1, e.getId());
	            //submit statement
	            preparedStmt.executeUpdate();
	        }
	        conn.commit();
	        preparedStmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new AccessException();
        }
	}

}
