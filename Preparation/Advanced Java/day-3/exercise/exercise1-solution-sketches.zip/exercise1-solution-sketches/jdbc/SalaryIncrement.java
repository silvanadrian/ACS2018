package exercise1.jdbc;

public class SalaryIncrement {

	private int department;
	private float incrementBy;
	
	public int getDepartment() {
		return department;
	}
	public void setDepartment(int department) {
		this.department = department;
	}
	public float getIncrementBy() {
		return incrementBy;
	}
	public void setIncrementBy(float incrementBy) {
		this.incrementBy = incrementBy;
	}
	
	

}
