package exercise1.djava;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		Employee john = new Employee("John Smith", 10000.0, null);
		Employee susan = new Employee("Susan Peterson", 8000.0, john);
		Employee mary = new Employee("Mary Sue", 8000.0, null);
		Employee troels = new Employee("Troels Andersen", 7500.0, mary);
		
		List<Box> boxes = new ArrayList<Box>();
		boxes.add(new Box(john));
		boxes.add(new Box(susan));
		boxes.add(new Box(mary));
		boxes.add(new Box(troels));
		boxes.add(new Box("Hello World!"));
		
		System.out.println("Printing a list containing 4 employees and a string:");
		for (Box box : boxes) {
			System.out.println(box);
		}
		System.out.println();

		System.out.println("Creating a new employee and printing it:");
		Box boxedName = new Box("Michael Reed");
		Box boxedSalary = new Box(4500.0);
		Box boxedSupervisor = new Box(mary);
		Box boxedEmployee = new Box("exercise1.djava.Employee", boxedName, boxedSalary, boxedSupervisor);
		System.out.println(boxedEmployee);
		System.out.println();

		System.out.println("Erroneous attempts to create objects:");
		System.out.println(new Box("nonexistant class name", new Box(42)));
		System.out.println(new Box("exercise1.djava.Employee", boxedName));
		System.out.println();

		System.out.println("Retrieving a field value and printing it:");
		System.out.println(boxedEmployee.get("supervisor"));
		System.out.println();
		
		System.out.println("Erroneous attempt to get field values:");
		System.out.println(boxedEmployee.get("notexistant field name"));
		System.out.println();

		System.out.println("Updating a field value and printing the mutated employee:");
		boxedEmployee.set("salary", new Box(5500));
		System.out.println(boxedEmployee);
		System.out.println();
		
		System.out.println("Erroneous attempts to set field values:");
		System.out.println(boxedEmployee.set("notexistant field name", new Box(null)));
		System.out.println(boxedEmployee.set("name", new Box(3)));
		System.out.println();

		System.out.println("Calling a method that returns a value:");
		System.out.println(boxedEmployee.call("getSupervisorName"));
		System.out.println("Calling a method that returns void and then printing the mutated employee:");
		boxedEmployee.call("raise", new Box((float)10));
		System.out.println(boxedEmployee);
		System.out.println();

		System.out.println("Erroneous attempts to invoke methods:");
		System.out.println(boxedEmployee.call("notexistant method name"));
		System.out.println(boxedEmployee.call("raise", new Box("a lot!")));
		System.out.println();

		System.out.println("Printing an employee containing a circular reference:");
		boxedEmployee.set("supervisor", boxedEmployee);
		System.out.println(boxedEmployee);
		System.out.println();
		
	}

}