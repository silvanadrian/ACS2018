package exercise1.djava;

public class Employee {

	public String name;
	public Double salary;
	public Employee supervisor;
	
	public Employee(String name, Double salary, Employee supervisor) {
		super();
		this.name = name;
		this.salary = salary;
		this.supervisor = supervisor;
	}
		
	public void raise(Float percentage) {
		salary = salary * (1 + percentage/100);
	}
	
	public String getSupervisorName() {
		return supervisor.name;
	}

}