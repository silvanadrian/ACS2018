package exercise1.djava;

import java.lang.reflect.*;

/**
 * A box that encapsulates an object, providing access to fields and method
 * through reflection.
 * 
 * @author fmma
 * 
 */
public class Box {
	////
	private final int MAX_TO_STRING_DEPTH = 4;

	/**
	 * The boxed object.
	 */
	private Object boxedObject;

	/**
	 * Creates a box of a given object.
	 * 
	 * @param obj
	 *            The object to box.
	 */
	public Box(Object obj) {
		this.boxedObject = obj;
	}

	/**
	 * Creates a new boxed object, by finding the constructor identified by
	 * className and the types of the input arguments boxedArgs, and calling it
	 * using reflection. If an exception is thrown, set the boxed object to the
	 * exception.
	 * 
	 * @param className
	 *            The class name of the constructor (e.g. "java.util.List").
	 * @param boxedArgs
	 *            The (boxed) arguments given to the constructor.
	 */
	public Box(String className, Box... boxedArgs) {
		// TODO
		Class<?>[] argClasses = new Class<?>[boxedArgs.length];
		Object[] args = new Object[boxedArgs.length];
		for (int i = 0; i < boxedArgs.length; i++) {
			Object arg  = boxedArgs[i].boxedObject;
			args[i] = arg;
			argClasses[i] = arg.getClass();
		}
		
		try {
			Class<?> c = Class.forName(className);
			Constructor<?> constr = c.getConstructor(argClasses);
			boxedObject = constr.newInstance(args);
		} catch (Exception ex) {
			boxedObject = ex;
		}
	}

	/**
	 * Lookup and return the content of a field identified by fieldName.
	 * 
	 * @param fieldName
	 *            The name of one of the fields of the boxed object.
	 * @return The (boxed) content of that field on success. A boxed exception
	 *         on failure.
	 */
	Box get(String fieldName) {
		// TODO
		//return null;
		Class<?> c = boxedObject.getClass();
		Object value;
		try {
			Field f = c.getField(fieldName);
			value = f.get(boxedObject);
		} catch (Exception ex) {
			value = ex;
		}
		return new Box(value);
	}

	/**
	 * Set the content of a field identified by fieldName.
	 * 
	 * @param fieldName
	 *            The name of one of the fields of the boxed object.
	 * @param value
	 *            A value to set the field to.
	 * @return null on success, a boxed exception on failure.
	 */
	Box set(String fieldName, Box value) {
		// TODO
		//return null;
		Class<?> c = boxedObject.getClass();
		try {
			Field f = c.getField(fieldName);
			f.set(boxedObject, value.boxedObject);
		} catch (Exception ex) {
			return new Box(ex);
		}
		return null;
	}

	/**
	 * Invoke a method on the boxed object using reflection.
	 * 
	 * @param methodName
	 *            The name of the method.
	 * @param boxedArgs
	 *            The input arguments to the method.
	 * @return The (boxed) return value of the method on success (void returns
	 *         (unboxed) null), or a boxed exception on failure.
	 */
	Box call(String methodName, Box... boxedArgs) {
		// TODO
		//return null;
		Class<?>[] argClasses = new Class<?>[boxedArgs.length];
		Object[] args = new Object[boxedArgs.length];
		for (int i = 0; i < boxedArgs.length; i++) {
			Object arg  = boxedArgs[i].boxedObject;
			args[i] = arg;
			argClasses[i] = arg.getClass();
		}
		
		Class<?> c = boxedObject.getClass();
		Object result;
		try {
			Method m = c.getMethod(methodName, argClasses);
			if (m.getReturnType() == void.class) {
				m.invoke(boxedObject, args);
				return null;
			} else
				result = m.invoke(boxedObject, args);
		} catch (Exception ex) {
			result = ex;
		}
		return new Box(result);
	}

	/**
	 * Returns the simple name of the class of the boxed object, followed by a
	 * key-value print of contents of the fields of the boxed object. E.g.
	 * Employee[age=30, salary=4000, name="John doe"].
	 * 
	 * Bonus points: If a field does not declare a toString method, use toString
	 * of Box recursively on that field. Recursion should be limited to some
	 * depth, so that cyclic references wont cause toString to loop forever.
	 */
	@Override
	public String toString() {
		// TODO
		//return null;
		return toString(1);
	}
	
	private String toString(int depth) {
		Class<?> c = boxedObject.getClass();
		StringBuilder sb = new StringBuilder();
		sb.append(c.getSimpleName());
		sb.append('[');
	
		Field[] fields = c.getFields();
		for (int i = 0; i < fields.length; i++) {
			if (i > 0)
				sb.append(", ");
			Field f = fields[i];
			sb.append(f.getName());
			sb.append('=');
			try {
				Object value = f.get(boxedObject);
				if (value != null && depth < MAX_TO_STRING_DEPTH)
				{
					Class<?> c2 = value.getClass();
					try {
						// Attempt to find a declared method toString()
						// If it exists, we just continue the normal flow
						// If it fails, we catch the exception and box the value
						// so that the Box.toString() implementation is used for it
						c2.getDeclaredMethod("toString");
						sb.append(value);
					} catch (NoSuchMethodException ex) {
						Box boxedValue = new Box(value);
						sb.append(boxedValue.toString(depth + 1));
					}
				}
				else
					sb.append(value);
			} catch (IllegalAccessException ex) {
				sb.append("<Illegal access>");
			}
		}
		sb.append(']');
		return sb.toString();
	}
}
