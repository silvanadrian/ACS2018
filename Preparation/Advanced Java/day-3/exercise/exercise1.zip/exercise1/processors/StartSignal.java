package exercise1.processors;

/**
 * A start signal.
 * 
 * @author fmma
 *
 */
public enum StartSignal {
	go;
}
