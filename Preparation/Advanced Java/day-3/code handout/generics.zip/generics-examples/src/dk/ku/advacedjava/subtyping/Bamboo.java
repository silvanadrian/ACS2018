package dk.ku.advacedjava.subtyping;

public class Bamboo extends Plant{

    @Override
    public String toString() {
        return "Bamboo!";
    }
    
}
