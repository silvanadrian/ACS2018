package dk.ku.advacedjava.subtyping.consumers;

import dk.ku.advacedjava.subtyping.Plant;

public class PlantConsumer implements Consumer<Plant> {

    @Override
    public void consume(Plant energy) {
        System.out.println("Comsuming " + energy.toString());
    }

}
