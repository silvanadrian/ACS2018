package dk.ku.advacedjava.generics;

public class DynamicCheckedPair {
    
    private Object first;
    private Object second;
    
    public Object getFirst() {
        return first;
    }
    public void setFirst(Object first) {
        this.first = first;
    }
    public Object getSecond() {
        return second;
    }
    public void setSecond(Object second) {
        this.second = second;
    }
}
