package dk.ku.advacedjava.subtyping.consumers;

public interface Consumer<T> {
    
    public void consume(T energy);
}
