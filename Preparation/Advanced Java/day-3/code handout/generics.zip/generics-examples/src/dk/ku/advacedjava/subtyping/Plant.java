package dk.ku.advacedjava.subtyping;

public class Plant extends EnergySource {

    @Override
    public String toString() {     
        return "Some green plant";
    }
    
}
