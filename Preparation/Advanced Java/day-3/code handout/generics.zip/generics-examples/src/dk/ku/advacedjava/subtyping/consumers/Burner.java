package dk.ku.advacedjava.subtyping.consumers;

import dk.ku.advacedjava.subtyping.EnergySource;

public class Burner implements Consumer<EnergySource>{

    @Override
    public void consume(EnergySource energy) {
        System.out.println("Burning " + energy.toString());
    }

}
