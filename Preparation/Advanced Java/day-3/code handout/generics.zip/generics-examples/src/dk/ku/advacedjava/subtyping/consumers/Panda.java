package dk.ku.advacedjava.subtyping.consumers;

import dk.ku.advacedjava.subtyping.Bamboo;

public class Panda implements Consumer<Bamboo> {

    @Override
    public void consume(Bamboo energy) {
        System.out.println("Eating " + energy.toString());
    }
    

}
