package dk.ku.advacedjava.subtyping;

public class EnergySource {
    @Override
    public String toString() {
        return "Some arbitrary energy source";
    }
}
